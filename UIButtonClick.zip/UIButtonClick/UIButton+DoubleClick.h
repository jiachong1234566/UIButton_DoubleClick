//
//  UIButton+DoubleClick.h
//  DaboPlayer
//
//  Created by 贾崇 on 2017/6/12.
//  Copyright © 2017年 dabo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (DoubleClick)

/**
 *  设置不可点击的时间间隔
 */
@property (nonatomic, assign) NSTimeInterval ds_acceptEventInterval;

@end
